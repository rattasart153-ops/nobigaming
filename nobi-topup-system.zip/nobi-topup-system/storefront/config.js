// ตั้งค่า URL ของ Backend API ที่นี่ก่อนเผยแพร่เว็บไซต์หน้าร้าน
// ตัวอย่าง: window.NOBI_API_URL = 'https://api.yourdomain.com';
window.NOBI_API_URL = 'http://localhost:3000';
