# Nobi Topup — แยกหน้าร้าน, Admin และ Backend

## โครงสร้าง
- `storefront/index.html` — เว็บไซต์หน้าร้านเดิมที่เชื่อมต่อ API สำหรับอ่านราคาและส่งคำสั่งซื้อ
- `storefront/config.js` — ตั้ง URL ของ Backend API สำหรับหน้าร้าน
- `admin/index.html` — ระบบ Admin แยกต่างหาก มีช่อง API URL และ Admin API Key
- `backend/server.js` — REST API พร้อมฐานข้อมูล SQLite
- `backend/.env.example` — ตัวอย่างค่าตั้งต้น

## เริ่ม Backend ในเครื่อง
ต้องติดตั้ง Node.js 20 ขึ้นไป

1. เปิด Terminal ในโฟลเดอร์ `backend`
2. ติดตั้งแพ็กเกจ: `npm install`
3. คัดลอก `.env.example` เป็น `.env`
4. เปลี่ยน `ADMIN_API_KEY` เป็นคีย์สุ่มยาวอย่างน้อย 32 ตัวอักษร และกำหนด `CORS_ORIGINS` เป็น origin ของหน้าร้าน/Admin ที่ใช้งานจริง
5. เริ่มระบบ: `npm start`
6. ตรวจสอบ `http://localhost:3000/api/health`

ฐานข้อมูลจะถูกสร้างที่ `backend/data/nobi.sqlite` โดยอัตโนมัติ และ seed แพ็กเกจตัวอย่างครั้งแรก

## เปิดหน้า Admin
เปิด `admin/index.html` ผ่าน local web server (แนะนำ ไม่เปิดเป็น file://) แล้วกรอก:
- **API URL** เช่น `http://localhost:3000`
- **Admin API Key** ค่าเดียวกับ `ADMIN_API_KEY` ใน `.env`

Admin มี Dashboard, ดูคำสั่งซื้อ, เปลี่ยนสถานะ, เพิ่ม/แก้ไข/ลบแพ็กเกจ และปิด/เปิดแพ็กเกจ

## เชื่อมหน้าร้าน
แก้ `window.NOBI_API_URL` ใน `storefront/config.js` ให้เป็น URL ของ Backend เช่น `https://api.example.com` แล้วโฮสต์ทั้งไฟล์หน้าร้านและ `config.js` ด้วยกัน หน้าร้านดึงแพ็กเกจจาก `GET /api/packages` และสร้างคำสั่งซื้อผ่าน `POST /api/orders`

## API หลัก
- `GET /api/health` — ตรวจสถานะ
- `GET /api/packages` — แพ็กเกจที่เปิดใช้งาน
- `POST /api/orders` — สร้างออเดอร์ (`game`, `amount`, `playerId`)
- `GET /api/admin/summary` — สรุปยอด (ต้องส่ง header `x-admin-api-key`)
- `GET/POST /api/admin/packages` — ดู/เพิ่มแพ็กเกจ
- `PUT/DELETE /api/admin/packages/:id` — แก้ไข/ลบแพ็กเกจ
- `GET /api/admin/orders?status=all|pending|completed|cancelled` — ดูออเดอร์
- `PATCH /api/admin/orders/:id/status` — เปลี่ยนสถานะ

## ข้อจำกัดและความปลอดภัย
- นี่เป็นระบบรับและจัดการคำสั่งซื้อ ไม่ได้เชื่อมผู้ให้บริการเติมเกมอัตโนมัติหรือระบบชำระเงินจริง การเปลี่ยนสถานะเป็น “สำเร็จ” ต้องเกิดหลังตรวจสอบการเติมจริง
- ก่อนใช้จริงต้องโฮสต์ Backend ด้วย HTTPS, ใช้ API key แบบสุ่มที่เก็บเป็น secret ฝั่งเซิร์ฟเวอร์, จำกัด `CORS_ORIGINS`, สำรองไฟล์ SQLite และใช้การจัดการ secret ของผู้ให้บริการโฮสต์
- API key สำหรับ Admin มีอำนาจสูง จึงไม่ควรแชร์ให้พนักงาน/ลูกค้า และไม่ควรฝังลงในหน้าร้าน
- สำหรับร้านที่มีหลายผู้ดูแล ควรพัฒนาการเข้าสู่ระบบรายบุคคล, rate limiting, audit log, CSRF/abuse controls และฐานข้อมูลบริการที่มี backup/restore ก่อนเปิดใช้จริง
- หาก Admin และ API อยู่คนละโดเมน ต้องเพิ่ม origin ทั้งสองใน `CORS_ORIGINS` เช่น `https://shop.example.com,https://admin.example.com`.
