'use strict';
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.ADMIN_API_KEY || '';
if (API_KEY.length < 32 || API_KEY.startsWith('change-this')) {
  console.error('ตั้งค่า ADMIN_API_KEY เป็น secret แบบสุ่มอย่างน้อย 32 ตัวอักษรใน .env ก่อนเริ่มใช้งาน');
  process.exit(1);
}
const dbFile = path.resolve(__dirname, process.env.DB_FILE || './data/nobi.sqlite');
fs.mkdirSync(path.dirname(dbFile), { recursive: true });
const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS packages (id INTEGER PRIMARY KEY AUTOINCREMENT, game TEXT NOT NULL, unit TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0), price REAL NOT NULL CHECK(price >= 0), active INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(game, amount));
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, order_code TEXT NOT NULL UNIQUE, game TEXT NOT NULL, amount INTEGER NOT NULL, unit TEXT NOT NULL, price REAL NOT NULL, player_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','completed','cancelled')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
`);
const seed = {
 'RoV':['คูปอง',[[90,15],[250,39],[500,75],[1100,159],[2200,299],[5500,699]]],
 'Free Fire':['เพชร',[[110,19],[341,59],[572,99],[1060,139],[2200,279],[5600,699]]],
 'Genshin Impact':['Genesis Crystal',[[60,35],[330,169],[1090,559],[2240,1190],[3880,1890],[8080,3590]]],
 'PUBG Mobile':['UC',[[60,25],[325,129],[660,259],[1800,679],[3850,1390],[8100,2790]]],
 'Mobile Legends':['Diamonds',[[86,20],[172,39],[257,59],[706,159],[2195,479],[4390,949]]],
 'Valorant':['VP',[[125,45],[420,149],[700,249],[1375,479],[2400,829],[4000,1350]]],
 'Honkai: Star Rail':['Oneiric Shard',[[60,39],[330,179],[1090,579],[2240,1250],[3880,1990],[8080,3790]]],
 'Call of Duty: Mobile':['CP',[[80,25],[420,129],[880,259],[2400,679],[5000,1390],[10000,2690]]],
 'Roblox':['Robux',[[80,29],[400,139],[800,269],[1700,559],[4500,1390],[10000,2990]]]
};
const insertPackage = db.prepare('INSERT OR IGNORE INTO packages(game,unit,amount,price) VALUES(?,?,?,?)');
const count = db.prepare('SELECT COUNT(*) n FROM packages').get().n;
if (!count) { const tx=db.transaction(()=>Object.entries(seed).forEach(([game,[unit,packs]])=>packs.forEach(([amount,price])=>insertPackage.run(game,unit,amount,price)))); tx(); }
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
const origins=(process.env.CORS_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
app.use(cors({origin(origin,cb){ if(!origin || origins.includes('*') || origins.includes(origin)) return cb(null,true); return cb(new Error('Origin not allowed by CORS')); }}));
app.use(express.json({limit:'100kb'}));
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'Nobi Topup API',time:new Date().toISOString()}));
app.get('/api/packages',(_req,res)=>res.json(db.prepare('SELECT id,game,unit,amount,price FROM packages WHERE active=1 ORDER BY game,id').all()));
app.post('/api/orders',(req,res)=>{
 const {game,amount,playerId}=req.body||{};
 if(typeof game!=='string'||!game.trim()||!Number.isInteger(Number(amount))||Number(amount)<=0||typeof playerId!=='string'||playerId.trim().length<1||playerId.trim().length>100) return res.status(400).json({error:'กรุณาตรวจสอบเกม แพ็กเกจ และ UID'});
 const pack=db.prepare('SELECT * FROM packages WHERE game=? AND amount=? AND active=1').get(game.trim(),Number(amount));
 if(!pack) return res.status(400).json({error:'ไม่พบแพ็กเกจนี้ หรือแพ็กเกจถูกปิดใช้งาน'});
 const code='NB'+Date.now().toString(36).toUpperCase()+Math.random().toString(36).slice(2,6).toUpperCase();
 const info=db.prepare('INSERT INTO orders(order_code,game,amount,unit,price,player_id) VALUES(?,?,?,?,?,?)').run(code,pack.game,pack.amount,pack.unit,pack.price,playerId.trim());
 res.status(201).json({id:info.lastInsertRowid,orderCode:code,game:pack.game,amount:pack.amount,unit:pack.unit,price:pack.price,status:'pending',message:'รับคำสั่งซื้อแล้ว ยังไม่ถือว่าเติมเกมสำเร็จ'});
});
function adminOnly(req,res,next){const supplied=req.get('x-admin-api-key')||'';if(!supplied||supplied.length!==API_KEY.length||!require('crypto').timingSafeEqual(Buffer.from(supplied),Buffer.from(API_KEY)))return res.status(401).json({error:'API Key ไม่ถูกต้อง'});next();}
app.use('/api/admin',adminOnly);
app.get('/api/admin/summary',(_req,res)=>{
 const total=db.prepare('SELECT COUNT(*) n FROM orders').get().n;
 const pending=db.prepare("SELECT COUNT(*) n FROM orders WHERE status='pending'").get().n;
 const completed=db.prepare("SELECT COUNT(*) n FROM orders WHERE status='completed'").get().n;
 const revenue=db.prepare("SELECT COALESCE(SUM(price),0) n FROM orders WHERE status='completed'").get().n;
 res.json({total,pending,completed,revenue});
});
app.get('/api/admin/packages',(_req,res)=>res.json(db.prepare('SELECT id,game,unit,amount,price,active,updated_at FROM packages ORDER BY game,amount').all()));
app.post('/api/admin/packages',(req,res)=>{
 const {game,unit,amount,price,active=true}=req.body||{};
 if(typeof game!=='string'||!game.trim()||typeof unit!=='string'||!unit.trim()||!Number.isInteger(Number(amount))||Number(amount)<=0||!Number.isFinite(Number(price))||Number(price)<0)return res.status(400).json({error:'ข้อมูลแพ็กเกจไม่ถูกต้อง'});
 try {const r=db.prepare('INSERT INTO packages(game,unit,amount,price,active,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)').run(game.trim(),unit.trim(),Number(amount),Number(price),active?1:0);res.status(201).json(db.prepare('SELECT * FROM packages WHERE id=?').get(r.lastInsertRowid));}catch(e){res.status(409).json({error:'แพ็กเกจเกมและจำนวนนี้มีอยู่แล้ว'});}
});
app.put('/api/admin/packages/:id',(req,res)=>{
 const {game,unit,amount,price,active}=req.body||{};
 if(typeof game!=='string'||!game.trim()||typeof unit!=='string'||!unit.trim()||!Number.isInteger(Number(amount))||Number(amount)<=0||!Number.isFinite(Number(price))||Number(price)<0)return res.status(400).json({error:'ข้อมูลแพ็กเกจไม่ถูกต้อง'});
 try{const r=db.prepare('UPDATE packages SET game=?,unit=?,amount=?,price=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(game.trim(),unit.trim(),Number(amount),Number(price),active?1:0,Number(req.params.id));if(!r.changes)return res.status(404).json({error:'ไม่พบแพ็กเกจ'});res.json(db.prepare('SELECT * FROM packages WHERE id=?').get(Number(req.params.id)));}catch(e){res.status(409).json({error:'แพ็กเกจเกมและจำนวนนี้ซ้ำกับรายการอื่น'});}
});
app.delete('/api/admin/packages/:id',(req,res)=>{const r=db.prepare('DELETE FROM packages WHERE id=?').run(Number(req.params.id));if(!r.changes)return res.status(404).json({error:'ไม่พบแพ็กเกจ'});res.json({ok:true});});
app.get('/api/admin/orders',(req,res)=>{const status=String(req.query.status||'all');const valid=['all','pending','completed','cancelled'];if(!valid.includes(status))return res.status(400).json({error:'สถานะไม่ถูกต้อง'});const rows=status==='all'?db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 1000').all():db.prepare('SELECT * FROM orders WHERE status=? ORDER BY id DESC LIMIT 1000').all(status);res.json(rows);});
app.patch('/api/admin/orders/:id/status',(req,res)=>{const {status}=req.body||{};if(!['pending','completed','cancelled'].includes(status))return res.status(400).json({error:'สถานะไม่ถูกต้อง'});const r=db.prepare('UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,Number(req.params.id));if(!r.changes)return res.status(404).json({error:'ไม่พบคำสั่งซื้อ'});res.json(db.prepare('SELECT * FROM orders WHERE id=?').get(Number(req.params.id)));});
app.use((err,_req,res,_next)=>{console.error(err.message);res.status(500).json({error:'เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์'});});
app.listen(PORT,()=>console.log(`Nobi Topup API listening on port ${PORT}`));
